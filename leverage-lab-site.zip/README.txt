# The Leverage Lab Website

Upload these files to a GitHub repository and enable GitHub Pages.

Files:
- index.html
- leverage-lab-logo.png
- mary-leverage-lab-badge.png

Edit `index.html` and replace `YOUR_GOOGLE_FORM_LINK_HERE` with your Google Form link.
